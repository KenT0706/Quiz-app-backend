<template>
 
</template>

<script>
export default {
  data() {
    return {
      totalTime: 100, // Total time in seconds
      remainingTime: 100, // Initial remaining time in seconds
    };
  },
  computed: {
    indicatorStyle() {
      const rotation = 360 - (360 * this.remainingTime) / this.totalTime;
      return { transform: `rotate(${rotation}deg)` };
    },
    formattedTime() {
      const minutes = Math.floor(this.remainingTime / 60);
      const seconds = this.remainingTime % 60;
      return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    },
  },
  methods: {
    startCountdown() {
      const timer = setInterval(() => {
        this.remainingTime--;
        if (this.remainingTime <= 0) {
          clearInterval(timer);
        }
      }, 1000);
    },
  },
  created() {
    this.startCountdown();
  },
  props: {
    elapsed: {
      type: Number,
      required: true,
    },
    limit: {
      type: Number,
      required: true,
    },
  },
};
</script>

<style scoped>
.countdown-timer {
  display: flex;
  justify-content: center;
  align-items: center;
}

.timer {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.dial {
  width: 200px;
  height: 200px;
  border: 8px solid #ccc;
  border-radius: 50%;
  position: relative;
  overflow: hidden;
  transform: rotate(270deg); /* Rotate the dial to start from the top */
  transition: transform 1s linear;
}

.indicator {
  position: absolute;
  width: 50%;
  height: 2px;
  background-color: #f00;
  top: 50%;
  left: 50%;
  transform-origin: left;
  transform: translateX(-50%);
}
.time {
  font-size: 24px;
  margin-top: 10px;
}
</style>
