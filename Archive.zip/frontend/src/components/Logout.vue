<template></template>

<script>

export default {
    setup() {
        localStorage.clear();
        window.location.href = '/';
    }
}
</script>